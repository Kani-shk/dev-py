import os
import datetime

def show_date():
    return datetime.datetime.today()
today = show_date
print(today)  # prints the current date and time

