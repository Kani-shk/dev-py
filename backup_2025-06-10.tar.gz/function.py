import os
command = 'df -h' #disk
command = 'date' #date
command = 'uptime' #load
command = 'sysctl hw.memsize' #RAM
def check_cpu(command):
    print(os.system(command))
def check_date(command):
    print(os.system(command))
def check_disk(command):
    print(os.system(command))
def check_RAM(command):
    print(os.system(command))

check_RAM('sysctl hw.memsize')
check_cpu('uptime')
check_date('date')
check_disk('df -h')
